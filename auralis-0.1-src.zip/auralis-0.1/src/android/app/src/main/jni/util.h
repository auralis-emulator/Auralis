// Copyright Auralis Emulator Project / Auralis Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

#pragma once

/// Calls and returns the value of NativeLibrary.isPortraitMode
bool IsPortraitMode();
